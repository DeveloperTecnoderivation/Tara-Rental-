<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model 
{
	
	 public function checkToken($token)
	{

		$this->db->where('user_token', $token);
		$query = $this->db->get('users');

		if($query->num_rows() == 1) {
			return true;
		}
		return false;
	} 

	public function getidbyToken($token)
	{
		$this->db->select('tbl_admin.id');
		$this->db->where('token', $token);
		$query = $this->db->get('tbl_admin');

		if($query->num_rows() == 1) {
			return $query->row();
		}
	} 


	public function loginDataByToken($user_token) 
	{

		$this->db->where('user_token', $user_token);
		$query = $this->db->get('users');

		if($query->num_rows() == 1) {
			return $query->row();
		}
	}

	public function allcategory()
	{
		$this->db->select('categories.*,cat.icon as icon,cat.icon as icon');
		$this->db->from('categories');
		$this->db->join('icon cat', 'cat.id=categories.icon_id', 'left');
		$this->db->order_by('categories.id', 'asc');
		$query = $this->db->get();

		return $query->result();
	}

	public function allfavoriteactivity($user_id)
	{
		$this->db->select('favorite.*,cat.activity_icon as activity_icon,cat.name as activity_name');
		$this->db->from('favorite');
		// $this->db->join('icon caton','caton.id=activities.activity_icon', 'left');
		$this->db->join('activities cat', 'cat.id=favorite.activity_id', 'left');
		$this->db->where('user_id', $user_id);
		// $this->db->order_by('favorite.iuser_d', 'asc');
		$query = $this->db->get();

		return $query->result();
	}

	public function geticonname($activity_icon)
	{
		$this->db->select('*');
		$this->db->from('icon');
		$this->db->where('id', $activity_icon);
		$query = $this->db->get();

		return $query->result();
	}

	public function get_category_color($category_id)
	{
		$this->db->select('*');
		$this->db->from('categories');
		$this->db->where('id', $category_id);
		$query = $this->db->get();

		return $query->result();
	}

	

	public function useractivity($user_id)
	{

		$this->db->select('*');
		$this->db->from('user_activities');
		$this->db->where('user_id', $user_id);
		$this->db->group_by('start_date');

		$this->db->order_by('user_activities.start_date', 'desc');
		$query = $this->db->get();

		
		return $query->result();
	}

	public function get_activity_by_date($start_date,$user_id)
	{

		$this->db->select('*');
		$this->db->from('user_activities');
		$this->db->where('start_date', $start_date);
		$this->db->where('user_id', $user_id);
		$this->db->order_by('user_activities.id', 'desc');

		$query = $this->db->get();
		// $str = $this->db->last_query();
  //  		 echo "<pre>";
 	// 	  print_r($str);

		return $query->result();
	}
	public function get_single_activity_by_date($start_date,$user_id,$activity_id)
	{

		$this->db->select('*');
		$this->db->from('user_activities');
		$this->db->where('start_date', $start_date);
		$this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$query = $this->db->get();
		// $str = $this->db->last_query();
  //  		 echo "<pre>";
 	// 	  print_r($str);

		return $query->result();
	}
	public function get_activity_by_activityid($activity_id)
	{

		$this->db->select('*');
		$this->db->from('activities');
		$this->db->where('id', $activity_id);
		$query = $this->db->get();
		return $query->result();
	}

	public function getSubactivity($activity_id)
	{

		$this->db->select('sub_activities.*,cat.icon as subactivity_icon');
		$this->db->from('sub_activities');
		$this->db->join('icon cat', 'cat.id=sub_activities.icon_id', 'left');
		$this->db->where('activity_id', $activity_id);
		$query = $this->db->get();
		return $query->result();
	}
	public function getSubactivityById($id)
	{

		$this->db->select('sub_activities.*,cat.icon as subactivity_icon');
		$this->db->from('sub_activities');
		$this->db->join('icon cat', 'cat.id=sub_activities.icon_id', 'left');
		$this->db->where('sub_activities.id', $id);
		$query = $this->db->get();
		return $query->result();
	}

	public function updatefavoriteactivity($id,$shopdata)
	{
		
		$this->db->where('id', $id);
		$result =  $this->db->update('favorite', $shopdata);
	    if($result){ return true; } else { return false; }

	}

	public function update_system($id,$shopdata)
	{
		
		$this->db->where('id', $id);
		$result =  $this->db->update('users', $shopdata);
	    if($result){ return true; } else { return false; }

	}

	public function update_user_activity($id,$shopdata)
	{
		
		$this->db->where('id', $id);
		$result =  $this->db->update('user_activities', $shopdata);
	    if($result){ return true; } else { return false; }

	}


	public function getUserData($user_id) 
	{

		$this->db->where('id', $user_id);
		$query = $this->db->get('users');

		if($query->num_rows() == 1) {
			return $query->row();
		}
	}

	public function addfavoriteactivity($categoryData)
	{
		$this->db->insert('favorite', $categoryData);
		$result =  $this->db->insert_id();
		if($result){ return true; } else { return false; }
	}

	public function addactivitysubmissions($categoryData)
	{
		$this->db->insert('pending_activities', $categoryData);
		$result =  $this->db->insert_id();
		if($result){ return true; } else { return false; }
	}
	public function addnewactivity($categoryData)
	{
		$this->db->insert('user_activities', $categoryData);
		$result =  $this->db->insert_id();
		if($result){ return true; } else { return false; }
	}

	public function get_category_by_id($category_id)
	{
		$this->db->select('categories.*,cat.icon as icon,cat.icon as icon');
		$this->db->from('categories');
		$this->db->join('icon cat', 'cat.id=categories.icon_id', 'left');
		$this->db->where('categories.id', $category_id);
		$query = $this->db->get();

		return $query->result();
	}

	public function all_activity($category_id)
	{
		
		$this->db->select('activities.*,caton.icon as new_activity_icon');
		$this->db->from('activities');
		$this->db->where('category_id', $category_id);
		$this->db->join('icon caton', 'caton.id=activities.activity_icon', 'left');
		// $this->db->where('category_id', $category_id);
		// $this->db->join('favorite cat', 'cat.activity_id=activities.id', 'left');
		$this->db->order_by('activities.name', 'asc');
		$query = $this->db->get();

		return $query->result();
	}

	public function check_favorite($user_id,$activity_id)
	{
		
		$this->db->select('*');
		$this->db->from('favorite');
		$this->db->where('activity_id', $activity_id);
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
// $str = $this->db->last_query();
//    		   echo "<pre>";
//  		  print_r($str);
//  		  die;
	return $query->result();
	}


	public function allactivitybyid($id)
	{
		
		$this->db->select('activities.*,cat.icon as new_activity_icon');
		$this->db->from('activities');
		$this->db->where('activities.id', $id);
		$this->db->join('icon cat', 'cat.id=activities.activity_icon', 'left');
		$query = $this->db->get();
		return $query->result();
	}

	public function getTotalRecord($table_name)
	{
		$this->db->select('*');
		$query = $this->db->get($table_name);
		return $query->num_rows(); 
	}


	public function userdelete($user_id){
		$this->db->where('id', $user_id);
		$result = $this->db->delete('users');
		if($result){ return true; } else { return false; }
	}

	public function workout_activity_weekly($user_id,$category_id,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('category_id', $category_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('end_date <=', $end_date);
		$query = $this->db->get('user_activities');
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function calories_count($user_id,$start_date,$end_date) 
	{

		
		$this->db->select_sum('calorie');
	    $this->db->from('health_metrics');
	    $this->db->where('user_id', $user_id);
		$this->db->where('date_time >=', $start_date);
		$this->db->where('date_time <=', $end_date);
		$query = $this->db->get();
		return $query->result();
	}

	public function step_count($user_id,$start_date,$end_date) 
	{

		
		$this->db->select_sum('step');
	    $this->db->from('health_metrics');
	    $this->db->where('user_id', $user_id);
		$this->db->where('date_time >=', $start_date);
		$this->db->where('date_time <=', $end_date);
		$query = $this->db->get();
		return $query->result();
	}

	public function workout_activity_monthly($user_id,$category_id,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('category_id', $category_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('end_date <=', $end_date);
		$query = $this->db->get('user_activities');
		$str = $this->db->last_query();
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function workout_activity_yearly($user_id,$category_id,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('category_id', $category_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('start_date <=', $end_date);
		$query = $this->db->get('user_activities');
		// $str = $this->db->last_query();
		//   echo "<pre>";
		//   print_r($str);
		//   die;
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function total_activity($user_id) 
	{

		$this->db->where('user_id', $user_id);
		$query = $this->db->get('user_activities');
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function total_workout_activity($user_id,$category_id) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('category_id', $category_id);
		$query = $this->db->get('user_activities');
		
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}


	public function total_combine_activity($user_id,$category_id1,$category_id2) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->group_start();
		$this->db->where('category_id', $category_id1);
		$this->db->or_where('category_id', $category_id2);
		$this->db->group_end();
		$query = $this->db->get('user_activities');
		$str = $this->db->last_query();
		  // echo "<pre>";
		  // print_r($str);
		  // die;
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}


	public function monthly_total_activity($user_id,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('start_date <=', $end_date);
		$query = $this->db->get('user_activities');
		// $str = $this->db->last_query();
		//   echo "<pre>";
		//   print_r($str);
		//   die;
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function get_category_id($activity_id)
	{
		
		$this->db->select('*');
		$this->db->from('activities');
		$this->db->where('activities.id', $activity_id);
		$query = $this->db->get();
		return $query->result();
	}

	public function admin_all_activity()
	{
		
		$this->db->select('activities.*,caton.icon as new_activity_icon,,cat.name as category_name');
		$this->db->from('activities');
		$this->db->join('icon caton', 'caton.id=activities.activity_icon', 'left');
		$this->db->join('categories cat', 'cat.id=activities.category_id', 'left');
		$query = $this->db->get();
		return $query->result();
	}

	public function total_count_activity($user_id,$activity_id) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$query = $this->db->get('user_activities');
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function all_activity_by_id($user_id,$activity_id)
	{
		
		$this->db->select('user_activities.*,caton.name as activity_name,cat.name as measurement,cater.name as classification');
		$this->db->from('user_activities');
		$this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->join('activities caton', 'caton.id=user_activities.activity_id', 'left');
		$this->db->join('measurements cat', 'cat.id=user_activities.measurement_id', 'left');
		$this->db->join('classifications cater', 'cater.id=user_activities.classification_id', 'left');
		$query = $this->db->get();

		// $str = $this->db->last_query();
		//   echo "<pre>";
		//   print_r($str);
		//   die;
		return $query->result();
	}


	public function monthly_category_wise_total_activity($user_id,$category_id,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('category_id', $category_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('start_date <=', $end_date);
		$query = $this->db->get('user_activities');
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function monthly_category_wise_combine_total_activity($user_id,$category_id1,$category_id2,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('start_date <=', $end_date);
		$where = "(category_id=".$category_id1." OR category_id=".$category_id2.")";
		$this->db->where($where);
		$query = $this->db->get('user_activities');
		// $str = $this->db->last_query();
		//   echo "<pre>";
		//   print_r($str);
		//   die;
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function deleteuseractivity($user_id,$activity_unique_id){
		$this->db->where('user_id', $user_id);
		$this->db->where('id', $activity_unique_id);
		$result = $this->db->delete('user_activities');
		if($result){ return true; } else { return false; }
	}

	public function checkactivity($user_id,$activity_unique_id){
		$this->db->where('user_id', $user_id);
		$this->db->where('id', $activity_unique_id);
		$query = $this->db->get('user_activities');

		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}

	}

	public function getsingleuseractivity($activity_unique_id)
	{
		
		$this->db->select('*');
		$this->db->from('user_activities');
		$this->db->where('id', $activity_unique_id);
		$query = $this->db->get();
		return $query->result();
	}

	public function useractivitybyactivityid($user_id,$activity_id)
	{

		$this->db->select('*');
		$this->db->from('user_activities');
		$this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->group_by('start_date');

		$this->db->order_by('user_activities.start_date', 'desc');
		$query = $this->db->get();

		
		return $query->result();
	}

	public function total_week_distance_single_activity($user_id,$activity_id,$start_date,$end_date)
	{

		 $this->db->select_sum('distance');
	    $this->db->from('user_activities');
	    $this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('end_date <=', $end_date);
		$query = $this->db->get();
		return $query->result();
	}
	public function total_week_duration_single_activity($user_id,$activity_id,$start_date,$end_date)
	{

		 $this->db->select_sum('duration');
	    $this->db->from('user_activities');
	    $this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('end_date <=', $end_date);
		$query = $this->db->get();
		return $query->result();
	}

	public function week_graph_mi($user_id,$activity_id,$start_date)
	{

		 $this->db->select_sum('distance');
	    $this->db->from('user_activities');
	    $this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->where('start_date', $start_date);
		$query = $this->db->get();
		// $str = $this->db->last_query();
		//   echo "<pre>";
		//   print_r($str);
		//   die;
		
		return $query->result();
	}


	public function total_monthly_distance_single_activity($user_id,$activity_id,$start_date,$end_date)
	{

		 $this->db->select_sum('distance');
	    $this->db->from('user_activities');
	    $this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('end_date <=', $end_date);
		$query = $this->db->get();
		return $query->result();
	}
	public function total_monthly_duration_single_activity($user_id,$activity_id,$start_date,$end_date)
	{

		 $this->db->select_sum('duration');
	    $this->db->from('user_activities');
	    $this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('end_date <=', $end_date);
		$query = $this->db->get();
		return $query->result();
	}

	public function monthly_total_single_activity($user_id,$activity_id,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('start_date <=', $end_date);
		$query = $this->db->get('user_activities');
		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function all_activity_subactivity($activity_id)
	{

		$this->db->select('sub_activities.*,caton.icon as sub_activity_icon');
	    $this->db->from('sub_activities');
	    $this->db->where('activity_id', $activity_id);
	    $this->db->join('icon caton', 'caton.id=sub_activities.icon_id', 'left');
		
		$query = $this->db->get();
		return $query->result();


	}

	public function total_week_subactivity_in_single_activity($user_id,$activity_id,$start_date,$end_date)
	{

		$this->db->select('*');
	    $this->db->from('user_activities');
	    $this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('start_date <=', $end_date);
		$query = $this->db->get();
		return $query->result();
	}

	public function total_count_subactivity($user_id,$subactivity_id,$start_date,$end_date) 
	{

		$this->db->where('user_id', $user_id);
		$this->db->where('sub_activity', $subactivity_id);
		$this->db->where('start_date >=', $start_date);
		$this->db->where('start_date <=', $end_date);
		$query = $this->db->get('user_activities');

		if($query->num_rows() >= 1) {
			return $query->num_rows();
		}else{
			return '0';
		}
	}

	public function add_new_health_metrics($healthMetricsData)
	{
		$this->db->insert('health_metrics', $healthMetricsData);
		$result =  $this->db->insert_id();
		if($result){ return true; } else { return false; }
	}

	public function checkactivityfavorite($user_id,$activity_id)
	{
		$this->db->select('*');
		$this->db->from('favorite');
		$this->db->where('user_id', $user_id);
		$this->db->where('activity_id', $activity_id);
		$query = $this->db->get();
		return $query->result();
	}

	public function getpaceunit($activity_id)
	{
		$this->db->select('activities.pace');
		$this->db->from('activities');
		$this->db->where('id', $activity_id);
		$query = $this->db->get();
		return $query->result();
	}

	public function update_streak($id,$shopdata)
	{
		
		$this->db->where('id', $id);
		$result =  $this->db->update('users', $shopdata);
	    if($result){ return true; } else { return false; }

	}

	public function get_user_streak_created($id)
	{
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('id', $id);
		$query = $this->db->get();
		return $query->result();
	}


}

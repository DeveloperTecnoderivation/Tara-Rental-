<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model 
{
	

	public function insertRecord($first_name,$last_name,$email,$phone_number,$provider,$social_id,$allow_password_change,$full_name,$user_token,$created_at,$updated_at,$status,$is_notified,$os,$os_version,$udid,$time_zone,$avatar,$measurement_system_id)
	{
		
		if($email){

		 $sql = "insert into users (first_name,last_name,email,phone_number,provider,social_id,allow_password_change,full_name,user_token,created_at,updated_at,status,is_notified,os,os_version,udid,time_zone,avatar,measurement_system_id) values ('$first_name','$last_name','$email','$phone_number','$provider','$social_id','$allow_password_change','$full_name','$user_token','$created_at','$updated_at','$status','$is_notified','$os','$os_version','$udid','time_zone','$avatar','$measurement_system_id')";
			$result = $this->db->query($sql);
			if($result) {
			return true;
			} else
			{ 
				return false;
			}
		}
	}

	public function check_email($email)
	{
		
		$this->db->select('*');
		$this->db->where('email', $email);
		$query = $this->db->get('users');

		// $str = $this->db->last_query();
		//   echo "<pre>";
		//   print_r($str);
		//   die;

		if($query->num_rows() == 1) {
			return true;
		} else
		{ 
			return false;
		}
		
	}

	public function login($email, $password) 
	{
		
		$this->db->where('email', $email);
		$this->db->where('password', $password);
		$query = $this->db->get('tbl_users');

		if($query->num_rows() == 1) {
			return $query->row();
		}
	}

	public function updateToken($email,$tokenData)
	{
		$this->db->where('email', $email);
		$result = $this->db->update('users', $tokenData);
		 if($result){ 
	 	return true;
	 	 } else { return false; }
	}

	public function getTokenData($email) 
	{

		$this->db->where('email', $email);
		$query = $this->db->get('users');

		if($query->num_rows() == 1) {
			return $query->row();
		}
	}

	public function get_hosting_details()
	{
		$this->db->select('tbl_admin.*');
		$this->db->from('tbl_admin');
		$query = $this->db->get();
		return $query->result();
	}

	

}
